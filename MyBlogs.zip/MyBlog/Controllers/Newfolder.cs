﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyBlog.Controllers
{
    public class Newfolder : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult MyDetails()
        {
            return View();
        }
    }
}
